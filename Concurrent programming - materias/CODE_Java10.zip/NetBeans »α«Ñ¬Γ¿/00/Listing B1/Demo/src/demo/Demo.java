package demo;

class Demo{
   public static void main(String[] args){
      System.out.println("Java & NetBeans");
   }
}

