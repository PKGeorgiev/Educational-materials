package showmeawindowdemo;

import javax.swing.JOptionPane;
class ShowMeAWindowDemo{
   public static void main(String[] args){
      JOptionPane.showMessageDialog(null,"Първа програма на Java!");
   }
}

