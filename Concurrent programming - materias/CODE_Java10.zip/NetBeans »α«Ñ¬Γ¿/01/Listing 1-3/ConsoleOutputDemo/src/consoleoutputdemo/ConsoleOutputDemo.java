package consoleoutputdemo;

// Дефиниране на класа ConsoleOutputDemo:
class ConsoleOutputDemo{
   // Главен метод на програмата:
   public static void main(String[] args){
      // Извеждане на съобщение в прозореца на конзолата
	  // (прозореца за извод):
      System.out.println("Ние учим езика Java!");
   }
}

