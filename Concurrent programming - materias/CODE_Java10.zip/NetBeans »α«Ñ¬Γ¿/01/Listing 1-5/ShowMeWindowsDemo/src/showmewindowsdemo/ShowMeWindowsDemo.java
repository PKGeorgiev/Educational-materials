package showmewindowsdemo;

import javax.swing.JOptionPane;
class ShowMeWindowsDemo{
   public static void main(String[] args){
      // Име на диалоговия прозорец:
      String title;
      // Текст на съобщението:
      String text;
      // Показване на първия прозорец с поле за въвеждане:
      title=JOptionPane.showInputDialog(null,"Име на прозореца:","Име",JOptionPane.WARNING_MESSAGE);
      // Показване на втори прозорец с поле за въвеждане:
      text=JOptionPane.showInputDialog(null,"Текст на съобщението:","Съдържание",JOptionPane.PLAIN_MESSAGE);
      // Показване на прозорец със съобщение:
      JOptionPane.showMessageDialog(null,text,title,JOptionPane.INFORMATION_MESSAGE);
   }
}


